#!/usr/bin/env python
import rospy
import tf
import roslib
#import Marker no marker available
import math
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Header
from geometry_msgs.msg import PointStamped
from geometry_msgs.msg import Point


LEFT = 1
RIGHT = 0

class avoider:
    def __init__(self):
        rospy.init_node('avoider')
        self.pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        self.sub = rospy.Subscriber('/base_scan', LaserScan, self.follow)
        self.listener = tf.TransformListener()
        self.safeDist = 1
        self.following = LEFT
        #self.m = Marker.Markers() no marker
        print "initial "

    def follow(self,ls):
        print"workingout angles in the follow function"
        a= ls.angle_min
        i= ls.angle_increment

        if self.following == RIGHT:
            start = -999
            end = 0
        else:
            start = 0
            end = 999

        rmin = 9999
        amin = 999
        for r in ls.ranges:
            if (a<=end and a>=start and r<rmin):
                amin=a
                rmin = r
            a+=i

        x = rmin*math.cos(amin)
        y = rmin*math.sin(amin)

        ps = PointStamped(header=Header(stamp=rospy.Time(0),frame_id="/base_laser_link"),point=Point(x, y, 0.0))
        p = self.listener.transformPoint("/base_link",ps)
        x=p.point.x
        y=p.point.y
        mag=math.sqrt(x*x+y*y)

        tx = 0
        ty = 0

        if (self.following==RIGHT):
            tx = -y
            ty = -x
        else:
            tx = y
            ty = x

        tx/=mag
        ty/=mag

        dx=x+tx-self.safeDist*x/mag
        dy=y+ty-self.safeDist*y/mag
        #self.m.add(dx,dy,0,0,1,0,"base_link") no marker

        theta=0

        if (dx>0 and rmin<ls.range_max):
            theta=math.atan(dy/dx)
        elif(self.following==RIGHT):
            theta=-1
        else:
            theta=1


        twist = Twist()
        if (dx>0):
            twist.linear.x=dx
        twist.angular.z=theta
        self.pub.publish(twist)
        #self.m.add(0,0,1,0,0,0,"base_link")  no marker
        #self.m.draw()



if __name__ == '__main__':
    try:
        node = avoider()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass