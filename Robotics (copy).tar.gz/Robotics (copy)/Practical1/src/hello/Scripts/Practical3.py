#!/usr/bin/env python
import rospy
import roslib
import math
import tf
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PointStamped
from std_msgs.msg import Header
from geometry_msgs.msg import Point


def transformbot(x,y):
    try:
        ps = PointStamped(header=Header(stamp=rospy.Time.now(), frame_id="/base_laser_link"),point=Point(x, y, 0.0))
        print listener.transformPoint("/base_link", ps) ,"_",Point(x,y,0)
    except (tf.LookupException):
        return


def checkDistance(laserScan):
    curAngle = laserScan.angle_min
    inc = laserScan.angle_increment

    for range in laserScan.ranges:
        x = range * math.cos(curAngle)
        y = range * math.sin(curAngle)
        transformbot(x,y)
        curAngle += inc



if __name__=='__main__':
    try:
        rospy.init_node('transformnode')
        listener = tf.TransformListener()
        laserSub=rospy.Subscriber('/base_scan',LaserScan,checkDistance)
        rospy.spin()
    except rospy.ROSInterruptException:
        pass