#!/usr/bin/env python
import rospy
import tf
import roslib
import Mark #refers to Mark.py, used for making markers on rviz
import math
import time
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Header
from geometry_msgs.msg import PointStamped
from geometry_msgs.msg import Point
from nav_msgs.msg import Odometry

class transformer: # initialises a transform node
    def __init__(self):
        rospy.init_node('transformer')
        self.publisher = rospy.Publisher('/real_robot_pose',PointStamped, queue_size=10)
        self.subscriber = rospy.Subscriber('/base_pose_ground_truth', Odometry, self.translateframe)
        self.listen = tf.TransformListener()
        self.p = Mark.Marks()
        print"initialised transformernodes"
        self.message=""

    def translateframe(self, truth_point): # publishes true point of robot and marks its pose
        #print"running translateframe"
        self.message="ran translateFrame"
        ps = PointStamped(header=Header(stamp=rospy.Time.now(), frame_id="/map"),point=truth_point.pose.pose.position)
        #print  ps
        newPoint = self.listen.transformPoint('/map',ps)# transforms point to correct frame of reference
        #print "yay i managed to transform point"
        self.publisher.publish(newPoint)
        self.p.adArrow(newPoint.point.x,newPoint.point.y,truth_point.pose.pose.orientation,1,0,1,"map") # draws robot position as marker
        self.p.draw()

if __name__ == '__main__':
    try:
        node = transformer()
        rospy.spin()
        print(node.message)
    except rospy.ROSInterruptException:
        pass