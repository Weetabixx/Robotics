#!/usr/bin/env python
import rospy
import roslib
import math
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from std_msgs.msg import Bool


class simplebot:
    def __init__(self):
        rospy.init_node('simplebot')
        self.min_range=1
        self.width=0.35

        self.subscriber=rospy.Subscriber('/base_scan',LaserScan,self.checkDistance)
        self.pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

    def checkDistance(self, laserScan):
        curAngle=laserScan.angle_min
        inc=laserScan.angle_increment
        nearby =False

        for range in laserScan.ranges:
            x=range*math.cos(curAngle)
            y=range*math.sin(curAngle)
            curAngle += inc
            if ((abs(y)<self.width/2) and (x<self.min_range)):
                print "Obstacle_at",x,"_",y,"_be_careful!"
                nearby = True
                tw = Twist()
                tw.linear.x = 0  # stop moving
                self.pub.publish(tw)
        if nearby == False:
            tw = Twist()
            tw.linear.x = 1  # move forward
            self.pub.publish(tw)


if __name__=='__main__':
    try:
        robot=simplebot()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass