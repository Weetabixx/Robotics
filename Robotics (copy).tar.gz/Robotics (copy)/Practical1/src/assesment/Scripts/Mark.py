#!/usr/bin/env python
import rospy
import roslib
from visualization_msgs.msg import Marker
from visualization_msgs.msg import MarkerArray

class Marks:
    def __init__(self):
        self.n = 0
        self.marks=[]
        self.publisher = rospy.Publisher("/scanMarkers",MarkerArray,queue_size=300)

    def adPoint(self,x,y,r,g,b,frame):
        point = Marker()
        point.header.frame_id=frame
        point.ns="basic"
        point.id=self.n
        point.type=point.SPHERE
        point.action=point.ADD
        point.pose.position.x=x
        point.pose.position.y=y
        point.pose.orientation.w=1
        point.scale.x=10
        point.scale.y=10
        point.scale.z=10
        point.color.r=r
        point.color.g=g
        point.color.b=b
        point.color.a=1.0
        self.marks.append(point)
        self.n+=1

    def adArrow(self,x,y,quat_theta,r,g,b,frame):
        point = Marker()
        point.header.frame_id = frame
        point.ns = "basic"
        point.id = self.n
        point.type = point.ARROW
        point.action = point.ADD
        point.pose.position.x = x
        point.pose.position.y = y
        point.pose.orientation = quat_theta
        point.scale.x = 10
        point.scale.y = 2
        point.scale.z = 2
        point.color.r = r
        point.color.g = g
        point.color.b = b
        point.color.a = 1.0
        self.marks.append(point)
        self.n += 1

    def draw(self):
        markArray=MarkerArray()
        for p in self.marks:
            markArray.markers.append(p)
        self.publisher.publish(markArray)
        self.n = 0

    def clear(self):
        markArray=MarkerArray()
        for p in self.marks:
            p.action=p.DELETE
            markArray.markers.append(p)
        self.publisher.publish(markArray)

if __name__=='__main__':
    try:
        rospy.init_node('markernode')
        pointa=Marks()
        pointa.ad(1,1,1,0,0,"base_pose_ground_truth")
        pointa.draw()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass