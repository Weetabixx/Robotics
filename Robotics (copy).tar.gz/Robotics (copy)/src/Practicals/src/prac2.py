#!/usr/bin/env python
import rospy
import roslib
import math
from sensor_msgs.msg import LaserScan

class simplebot:
    def __init__(self):
        rospy.init_node(`simplebot`)
        self.min_range=0.5
        self.width=0.35

        self.subscriber=rospy.Subscriber(`/base_scan`,LaserScan,self.checkDistance)
        
    def checkDistance(self,laserScan):
        curAngle=lserScan.angle_min
        inc=laserScan.angle_increment

        for range in laserScan.ranges:
            x=range*math.cos(curAngle)
            y=range*math.sin(curAngle)

            if ((abs(y)<self.width/) and (x<self.min_range)):
                print "Obstacle at",x," ",y,", be careful!"

        curAngle=curAngle+inc
robot=simplebot()
rospy.spin()
