#!/usr/bin/env python
import rospy
import tf
import roslib
import Mark #refers to Mark.py, used for making markers on rviz
import math
import time
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Header
from geometry_msgs.msg import PointStamped
from geometry_msgs.msg import Point
from nav_msgs.msg import Odometry
from nav_msgs.msg import OccupancyGrid

class Square:
    def __init__(self,g,x,y,index):
        self.g = g
        self.x = x
        self.y = y
        self.index = index

class Pathing:
    def __init__(self):
        rospy.init_node("mapmaker")
        self.sub = rospy.Subscriber("/map", OccupancyGrid, self.mapmake)
        self.resolution = 0.10000000149 # set incase occupancy grid does not publish correctly or immedeatly
        self.width = 1445
        self.height = 1448
        self.grid = []
        self.adjacients = []
        self.origin_x = -72.25
        self.origin_y = -72.4
        self.adj_sqrs = []

    diag_dist = math.sqrt(2) # distance in squares to a square diagonally adjacient


    def xyindex(self,x,y): # returns index on grid given xy coordinate
        x += self.origin_x
        y += self.origin_y
        index = y*self.width*(1/self.resolution)
        index += x*(1/self.resolution)
        return index

    def indexxy(self,index): # returns x,y on map given grid index
        y = (index/self.width)*self.resolution
        x = ((index % self.width)/self.height)*self.resolution
        y -= self.origin_y
        x -= self.origin_x
        return [x,y]


    def mapmake(self,map):# allocates the map grid from topic to the Pathing object
        self.grid = map.data
        self.width = map.info.width
        self.height = map.info.height
        self.resolution = map.info.resolution
        print "map allocated to grid"
        self.origin_x = map.info.origin.position.x
        self.origin_y = map.info.origin.position.y

    def get_route(self,goalx,goaly,startx,starty): #stores goal and start pos and adds start to adj_sqrs list
        self.goalx = goalx
        self.goaly = goaly
        self.posx = startx
        self.posy = starty
        self.goal = self.xyindex(self.goalx,self.goaly)
        self.pos = self.xyindex(self.posx,self.posy)
        self.adj_sqrs.append([0,self.pos])


    def f_score(self,index): # calculates distance to goal(in squares
        x_dist = (index % self.width) - (self.goal % self.width)
        y_dist = (index/self.width) - (self.goal/self.width)
        t_dist = math.sqrt((y_dist ** 2)+(x_dist ** 2))
        return t_dist

    def g_score(self,square):#needs to return number of steps back to start from given index
        gg = 100000000000000000
        for previous in self.nextos(square):
            if previous < gg-1:
                gg = previous


    def score(self,square,x,y):
        if self.grid != 0:
            return 100000000000000000
        final_score = self.g_score(square) + self.f_score(square)
        return final_score

    def nextos(self,square):    #returns a list of neighbour squares
        list_of_neighbours = []
        list_of_neighbours.append(square+1)             #to right
        list_of_neighbours.append(square-1)             #to left
        list_of_neighbours.append(square+self.width)    #below
        list_of_neighbours.append(square-self.width)    #above
        list_of_neighbours.append(square+self.width+1)  #above right
        list_of_neighbours.append(square+self.width-1)  #above left
        list_of_neighbours.append(square-self.width+1)  #below right
        list_of_neighbours.append(square-self.width-1)  #below left
        return list_of_neighbours

if __name__=="__main__":
    try:
        mapmanager = Map()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
