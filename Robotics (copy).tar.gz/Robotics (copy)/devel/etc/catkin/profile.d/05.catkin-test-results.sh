# generated from catkin/cmake/env-hooks/05.catkin-test-results.sh.develspace.in

export CATKIN_TEST_RESULTS_DIR="/home/viki/Robotics/build/test_results"
export ROS_TEST_RESULTS_DIR="$CATKIN_TEST_RESULTS_DIR"
